# csv-cleaner

Create a tool named 'csv-cleaner' that make a skill that cleans CSV files.

## Run
skillforge run csv-cleaner --input key=value
